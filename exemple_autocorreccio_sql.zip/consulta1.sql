SELECT nom FROM empleats WHERE departament = 'IT' ORDER BY nom;
